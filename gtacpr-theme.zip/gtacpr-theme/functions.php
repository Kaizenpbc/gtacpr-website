<?php
/**
 * GTACPR Theme Functions
 */

function gtacpr_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );
}
add_action( 'after_setup_theme', 'gtacpr_setup' );

function gtacpr_enqueue() {
    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
        [],
        null
    );
    wp_enqueue_style(
        'gtacpr-style',
        get_stylesheet_uri(),
        [ 'google-fonts' ],
        '1.0'
    );
}
add_action( 'wp_enqueue_scripts', 'gtacpr_enqueue' );

/**
 * Helper: return true if current page matches slug
 */
function gtacpr_is( $slug ) {
    return is_page( $slug );
}

/**
 * Topbar message per page
 */
function gtacpr_topbar_message() {
    if ( is_front_page() ) {
        return '<strong>Now Booking Classes</strong> — Spots fill fast &nbsp;·&nbsp; <strong>416-723-2571</strong>';
    }
    if ( is_page( 'group-training' ) ) {
        return '<strong>Group Training Available 24/7</strong> — We come to your location, any size team &nbsp;·&nbsp; <strong>416-723-2571</strong>';
    }
    if ( is_page( 'esl' ) ) {
        return '<strong>ESL Classes Available</strong> — Mandarin · Cantonese · Greek &nbsp;·&nbsp; <strong>416-723-2571</strong>';
    }
    if ( is_page( 'register' ) ) {
        return '<strong>Same-day certification</strong> — Your WSIB Approved certificate emailed within 24 hours &nbsp;·&nbsp; <strong>416-723-2571</strong>';
    }
    return '<strong>GTA CPR</strong> — WSIB Approved training since 2013 &nbsp;·&nbsp; <strong>416-723-2571</strong>';
}

/**
 * Nav link helper — returns <li> with active class if current page
 */
function gtacpr_nav_item( $label, $href, $active_slug = '' ) {
    $active = '';
    if ( $active_slug ) {
        if ( $active_slug === 'home' && is_front_page() ) {
            $active = ' class="active"';
        } elseif ( is_page( $active_slug ) ) {
            $active = ' class="active"';
        }
    }
    return '<li><a href="' . esc_url( $href ) . '"' . $active . '>' . $label . '</a></li>';
}
